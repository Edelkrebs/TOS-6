#ifndef __ISR_H
#define __ISR_H

void isr_handler(void* e);

#endif
