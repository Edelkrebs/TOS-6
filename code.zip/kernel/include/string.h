#ifndef __STRING_H
#define __STRING_H

#include <stddef.h>

size_t strlen(const char* str);

#endif